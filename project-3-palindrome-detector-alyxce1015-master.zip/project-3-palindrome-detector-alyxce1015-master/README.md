# Project - Palindrome Detector

Created a palindrome detector

# My Information

* name: Alyx Cui Edio
* CWID: 885822205
* Email: acui@csu.fullerton.edu
